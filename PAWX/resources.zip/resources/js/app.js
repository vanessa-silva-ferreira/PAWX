import './bootstrap';

import './birthdate-age.js'
import './pet-form.js'
import './home-carousel.js'
import './home-remember.js'
import './home-feedback.js'
import './home-header.js'
