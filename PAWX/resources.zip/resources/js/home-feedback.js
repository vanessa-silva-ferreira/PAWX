document.addEventListener('DOMContentLoaded', () => {
    const feedbackCarousel = document.getElementById('feedbackCarousel');
    const prevFeedback = document.getElementById('prevFeedback');
    const nextFeedback = document.getElementById('nextFeedback');

    if (!feedbackCarousel || !prevFeedback || !nextFeedback) {
        console.error('Um ou mais elementos do carrossel de feedback não foram encontrados.');
        return;
    }

    const feedbackData = [
        { nome: 'Pedro A.', data: '1 de dezembro de 2024', pontuacao: '9/10', mensagem: 'Excelente atendimento ao meu gato! Serviço simpático e cuidadoso. Recomendo muito.', imagem: 'https://randomuser.me/api/portraits/men/1.jpg' },
        { nome: 'Ana B.', data: '27 de novembro de 2024', pontuacao: '9.5/10', mensagem: 'O meu cão adorou o corte e ficou muito mais calmo. Ambiente limpo e organizado.', imagem: 'https://randomuser.me/api/portraits/women/2.jpg' },
        { nome: 'João C.', data: '25 de novembro de 2024', pontuacao: '8.5/10', mensagem: 'Ótimo corte e tratamento para o meu cão. Preço justo e ótimo atendimento.', imagem: 'https://randomuser.me/api/portraits/men/3.jpg' },
        { nome: 'Sara D.', data: '20 de novembro de 2024', pontuacao: '10/10', mensagem: 'Nota 10 para o atendimento e serviços. A minha gata foi muito bem tratada.', imagem: 'https://randomuser.me/api/portraits/women/4.jpg' },
        { nome: 'Miguel P.', data: '18 de novembro de 2024', pontuacao: '9/10', mensagem: 'Sempre bem atendido, recomendo! Excelente para banho e corte de unhas.', imagem: 'https://randomuser.me/api/portraits/men/5.jpg' },
        { nome: 'Joana F.', data: '15 de novembro de 2024', pontuacao: '8/10', mensagem: 'O meu gato adorou o banho! Muito obrigado por cuidarem tão bem dele.', imagem: 'https://randomuser.me/api/portraits/women/6.jpg' },
        { nome: 'Manuel R.', data: '10 de novembro de 2024', pontuacao: '9.5/10', mensagem: 'Serviço impecável. O meu cão foi tratado com muito carinho e ficou super feliz. Recomendo a todos.', imagem: 'https://randomuser.me/api/portraits/men/7.jpg' },
        { nome: 'Beatriz L.', data: '5 de novembro de 2024', pontuacao: '9.8/10', mensagem: 'Muito atenciosos! O meu gato ficou super tranquilo e bem tratado. Recomendo bastante.', imagem: 'https://randomuser.me/api/portraits/women/8.jpg' },
        { nome: 'Sofia T.', data: '3 de novembro de 2024', pontuacao: '10/10', mensagem: 'Fiquei muito satisfeita com o corte de unhas do meu gato. Ambiente tranquilo.', imagem: 'https://randomuser.me/api/portraits/women/9.jpg' },
        { nome: 'Carlos E.', data: '1 de novembro de 2024', pontuacao: '8.5/10', mensagem: 'Muito bom atendimento e profissionalismo. Recomendo para quem quer o melhor para o seu pet.', imagem: 'https://randomuser.me/api/portraits/men/10.jpg' },
        { nome: 'Inês M.', data: '30 de outubro de 2024', pontuacao: '9/10', mensagem: 'O meu cão adorou o banho e corte! Excelente ambiente.', imagem: 'https://randomuser.me/api/portraits/women/11.jpg' },
        { nome: 'Rui N.', data: '28 de outubro de 2024', pontuacao: '8/10', mensagem: 'O atendimento foi bom e o meu cão saiu de lá muito calmo. Obrigado!', imagem: 'https://randomuser.me/api/portraits/men/12.jpg' },
        { nome: 'Maria J.', data: '25 de outubro de 2024', pontuacao: '9.5/10', mensagem: 'Nota máxima! O meu gato adorou e ficou lindíssimo após o corte.', imagem: 'https://randomuser.me/api/portraits/women/13.jpg' },
        { nome: 'Tomás C.', data: '20 de outubro de 2024', pontuacao: '9/10', mensagem: 'Banho excelente e serviço simpático. Recomendo muito.', imagem: 'https://randomuser.me/api/portraits/men/14.jpg' },
        { nome: 'Carla L.', data: '15 de outubro de 2024', pontuacao: '10/10', mensagem: 'Atendimento impecável, recomendo sem dúvida.', imagem: 'https://randomuser.me/api/portraits/women/15.jpg' },
        { nome: 'Leonor S.', data: '10 de outubro de 2024', pontuacao: '9.8/10', mensagem: 'Muito carinho com os animais e o serviço foi ótimo.', imagem: 'https://randomuser.me/api/portraits/women/16.jpg' },
        { nome: 'Ricardo T.', data: '5 de outubro de 2024', pontuacao: '9/10', mensagem: 'Muito bom serviço! O meu cão ficou super cheiroso.', imagem: 'https://randomuser.me/api/portraits/men/17.jpg' },
        { nome: 'Marta F.', data: '1 de outubro de 2024', pontuacao: '8.5/10', mensagem: 'Gostei muito do atendimento e do ambiente.', imagem: 'https://randomuser.me/api/portraits/women/18.jpg' },
        { nome: 'André M.', data: '28 de setembro de 2024', pontuacao: '9/10', mensagem: 'Serviço rápido e eficiente. Muito obrigado.', imagem: 'https://randomuser.me/api/portraits/men/19.jpg' },
        { nome: 'Cláudia V.', data: '25 de setembro de 2024', pontuacao: '10/10', mensagem: 'Adorei o atendimento! Recomendo a todos os meus amigos.', imagem: 'https://randomuser.me/api/portraits/women/20.jpg' }
    ];

    feedbackData.forEach(feedback => {
        const card = document.createElement('div');
        card.className = 'feedback-card';
        card.innerHTML = `
            <img src="${feedback.imagem}" alt="${feedback.nome}">
            <h3>${feedback.nome}</h3>
            <p>${feedback.mensagem}</p>
            <span>${feedback.pontuacao}</span>
        `;
        feedbackCarousel.appendChild(card);
    });

    let currentIndex = 0;

    const updateCarousel = () => {
        feedbackCarousel.style.transform = `translateX(-${currentIndex * 270}px)`;
    };

    prevFeedback.addEventListener('click', () => {
        if (currentIndex > 0) {
            currentIndex--;
            updateCarousel();
        }
    });

    nextFeedback.addEventListener('click', () => {
        if (currentIndex < feedbackCarousel.children.length - 1) {
            currentIndex++;
            updateCarousel();
        }
    });

    setInterval(() => {
        if (currentIndex < feedbackCarousel.children.length - 1) {
            currentIndex++;
        } else {
            currentIndex = 0;
        }
        updateCarousel();
    }, 5000);
});
