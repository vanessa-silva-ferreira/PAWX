<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PAWX - Cuidados para Animais</title>
    <script src="https://cdn.tailwindcss.com"></script>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="bg-white font-sans text-gray-800">

@include('welcome-header')

<div class="carousel-wrapper">
    <div class="carousel-container">
        <div class="carousel-images"></div>
    </div>
</div>

<section class="bg-gray-100 p-6 relative -mb-4">
    <div class="max-w-6xl mx-auto relative">
        <button id="prevFeedback" class="arrow left">‹</button>
        <button id="nextFeedback" class="arrow right">›</button>
        <div id="feedbackCarousel" class="flex gap-6"></div>
    </div>
</section>


@include('welcome-footer')

</body>
</html>
