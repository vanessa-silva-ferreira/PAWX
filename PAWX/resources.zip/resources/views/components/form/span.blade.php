<div>
    <span {{ $attributes }}>
    {{ $slot }}
    </span>
</div>
