<div>
    <label
        {{ $attributes }}
        class="uppercase absolute top-2 left-4 text-sm text-pawx-brown/50
        transition-all duration-200 pointer-events-none transform origin-left scale-100
        focus-within:scale-75 focus-within:-translate-y-2 bg-white">
        {{ $slot }}
    </label>
</div>
