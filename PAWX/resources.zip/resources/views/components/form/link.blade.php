<div>
    <a {{ $attributes }}>
        {{ $slot }}
    </a>
</div>
