<h1 class="text-xl font-semibold text-pawx-orange uppercase">{{$slot}}</h1>
