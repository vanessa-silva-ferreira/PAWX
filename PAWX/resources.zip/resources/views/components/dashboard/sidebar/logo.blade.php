<div class="flex items-center space-x-3">
    <div class="w-8 h-8 bg-gray-100 rounded"></div>
    <h2 id="menu-text" class="text-xl text-gray-400 font-semibold">PAWX</h2>
</div>
