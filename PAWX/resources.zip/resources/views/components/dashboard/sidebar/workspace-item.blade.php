<a href="{{ $href }}" class="flex items-center px-4 py-2 text-gray-300 hover:bg-pawx-brown">
    <span class="w-2 h-2 bg-pawx-orange rounded-full mr-3"></span>
    <span id="menu-text" class="sidebar-full-only">{{ $label }}</span>
</a>
