<a href="{{ $href }}" {{ $attributes->merge(['class' => 'text-sm text-pawx-orange']) }}>
    {{ $slot }}
</a>
