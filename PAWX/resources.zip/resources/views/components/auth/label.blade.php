<label for="{{ $for }}" {{ $attributes->merge(['class' => 'block text-pawx-brown mb-1 text-sm']) }}>
    {{ $slot }}
</label>
